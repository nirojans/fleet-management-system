.. python-gsmmodem documentation master file, created by
   sphinx-quickstart on Sun Aug 11 20:50:25 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to python-gsmmodem's documentation!
===========================================


.. include:: ../README.rst

.. automodule:: gsmmodem


Examples and API
================

.. toctree::
   :maxdepth: 3

   examples.rst
   api.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

