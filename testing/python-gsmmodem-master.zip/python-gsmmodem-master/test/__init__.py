""" Tests for python-gsmmodem """
